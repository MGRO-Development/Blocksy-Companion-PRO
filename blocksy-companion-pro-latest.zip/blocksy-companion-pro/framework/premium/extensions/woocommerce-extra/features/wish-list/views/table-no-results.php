<div class="woocommerce-Message woocommerce-Message--info woocommerce-info">
	<a class="woocommerce-Button button" href="<?php echo esc_url(apply_filters('woocommerce_return_to_shop_redirect', wc_get_page_permalink('shop'))); ?>">
		<?php echo __('Browse products', 'blocksy-companion') ?>
	</a>

	<?php echo __("You don't have any products in your wish list yet.", 'blocksy-companion') ?>
</div>
