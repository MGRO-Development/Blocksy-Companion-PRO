<?php

namespace Blocksy\Extensions\WoocommerceExtra;

$consent = '';

if (function_exists('blocksy_ext_cookies_checkbox')) {
	$consent = blocksy_ext_cookies_checkbox('waitlist');
}

$form = blocksy_html_tag(
	'form',
	[
		'class' => 'ct-product-waitlist-form',
		'action' => esc_url(admin_url('admin-post.php')),
		'method' => 'post',
	],
	blocksy_html_tag(
		'input',
		[
			'type' => 'email',
			'name' => 'email',
			'value' => is_user_logged_in() ? wp_get_current_user()->user_email : '',
			'placeholder' => __(
				'Enter your email',
				'blocksy-companion'
			),
			'required' => true,
		]
	) .
	blocksy_html_tag(
		'button',
		[
			'class' => 'ct-button',
			'type' => 'submit',
		],
		__('Join Waitlist', 'blocksy-companion')
	) .
	$consent
);

$products_type = blocksy_get_theme_mod('waitlist_type', 'boxed');

$section_title = blocksy_html_tag(
	'h5',
	[
		'class' => 'ct-waitlist-title'
	],
	__('This product is currently sold out!', 'blocksy-companion')
);

$section_message = blocksy_html_tag(
	'p',
	[
		'class' => 'ct-waitlist-message'
	],
	__('No worries! Please enter your e-mail address and we will promptly notify you as soon as the item is back in stock.', 'blocksy-companion')
);

$section_success_message = blocksy_html_tag(
	'p',
	[
		'class' => 'ct-waitlist-message'
	],
	__('Great! You have been added to the waitlist for this product. Please check your inbox and confirm the subscription to this waitlist.', 'blocksy-companion')
);

if (
	is_user_logged_in()
	||
	$state === 'subscribed-confirmed'
) {
	$section_success_message = blocksy_html_tag(
		'p',
		[
			'class' => 'ct-waitlist-message'
		],
		__('Great! You have been added to the waitlist for this product. You will receive an email as soon as the item is back in stock.', 'blocksy-companion')
	);
}

if (
	$state === 'subscribed-confirmed'
	&&
	! is_user_logged_in()
) {
	$state = 'subscribed';
}

$section_subscribed_users = '';

if (blocksy_get_theme_mod('waitlist_show_users_number', 'no') === 'yes') {
	$count_data = ProductWaitlistLayer::get_users_count($product_id);

	$section_subscribed_users = blocksy_html_tag(
		'p',
		[
			'class' => 'ct-waitlist-users',
			'data-count' => $count_data['waitlist_users'],
		],
		$count_data['message']
	);
}

echo blocksy_html_tag(
	'div',
	[
		'class' => 'ct-product-waitlist',
		'data-type' => $products_type,
		'data-state' => $state
	],
	blocksy_html_tag(
		'div',
		[
			'class' => 'ct-waitlist-initial-state'
		],
		$section_title .
		$section_message .
		$form .
		$section_subscribed_users
	) .
	blocksy_html_tag(
		'div',
		[
			'class' => 'ct-waitlist-subscribed-state'
		],
		$section_success_message .
		blocksy_html_tag(
			'button',
			[
				'class' => 'ct-button unsubscribe',
				'type' => 'submit',
				'data-token' => $unsubscribe_token,
				'data-id' => $subscription_id,
			],
			__('Unsubscribe', 'blocksy-companion')
		) .
		$section_subscribed_users
	),
	
);