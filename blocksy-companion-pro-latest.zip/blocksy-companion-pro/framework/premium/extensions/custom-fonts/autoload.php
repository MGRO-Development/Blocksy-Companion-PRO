<?php

$autoload = [
	'Storage' => 'includes/storage.php'
];

